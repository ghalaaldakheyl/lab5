from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import reverse

# Create your views here.
class Person:
    def __init__(self, username, password):
        self.username = username
        self.password = password


people=[]


def add_person(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        new_person = Person(username, password)
        people.append(new_person)
        return redirect(reverse('app5:list'))

    return render(request, 'app5/add.html')


def list_people(request):
    usernames = [person.username for person in people]
    return render(request, 'app5/list.html', {'usernames': usernames})