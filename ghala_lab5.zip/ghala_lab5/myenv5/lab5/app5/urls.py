from django.urls import path
from . import views

app_name = 'app5'

urlpatterns = [
    path('', views.list_people, name='list'),
    path('add/', views.add_person, name='add'),
]
